# Bazi API

This is a Node.js API for calculating Bazi using the @tony801015/chinese-lunar package.
